import axios from 'axios';

const API_KEY = process.env.EXPO_PUBLIC_OPENWEATHER_API_KEY || '';
const BASE = 'https://api.openweathermap.org/data/2.5';

export type Weather = {
  name: string; country?: string; temp: number; feelsLike: number; humidity: number;
  wind: number; description: string; icon: string; condition: string; pressure: number;
  visibility: number; sunrise: number; sunset: number; lat: number; lon: number; uv?: number;
};
export type ForecastDay = { date: string; min: number; max: number; icon: string; description: string; items: {time:string; temp:number; icon:string}[] };

function ensureKey() { if (!API_KEY) throw new Error('API key missing. Add EXPO_PUBLIC_OPENWEATHER_API_KEY to your .env file.'); }
function mapWeather(data: any): Weather {
  return { name:data.name, country:data.sys?.country, temp:Math.round(data.main.temp), feelsLike:Math.round(data.main.feels_like), humidity:data.main.humidity, wind:data.wind.speed, description:data.weather?.[0]?.description || 'Clear', icon:data.weather?.[0]?.icon || '01d', condition:data.weather?.[0]?.main || 'Clear', pressure:data.main.pressure, visibility:Math.round((data.visibility || 0)/1000), sunrise:data.sys.sunrise, sunset:data.sys.sunset, lat:data.coord.lat, lon:data.coord.lon };
}
export async function getWeatherByCity(city:string):Promise<Weather> { ensureKey(); const {data}=await axios.get(`${BASE}/weather`,{params:{q:city,appid:API_KEY,units:'metric'},timeout:12000}); return mapWeather(data); }
export async function getWeatherByCoords(lat:number,lon:number):Promise<Weather> { ensureKey(); const {data}=await axios.get(`${BASE}/weather`,{params:{lat,lon,appid:API_KEY,units:'metric'},timeout:12000}); return mapWeather(data); }
export async function searchCities(query:string):Promise<{name:string;country:string;state?:string;lat:number;lon:number}[]> { ensureKey(); const {data}=await axios.get('https://api.openweathermap.org/geo/1.0/direct',{params:{q:query,limit:6,appid:API_KEY},timeout:12000}); return data; }
export async function getForecast(lat:number,lon:number):Promise<ForecastDay[]> { ensureKey(); const {data}=await axios.get(`${BASE}/forecast`,{params:{lat,lon,appid:API_KEY,units:'metric'},timeout:12000}); const groups:Record<string,any[]>={}; for(const item of data.list){const key=new Date(item.dt*1000).toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'}); (groups[key] ||= []).push(item);} return Object.entries(groups).slice(0,5).map(([date,items])=>{const temps=items.map(x=>x.main.temp); const mid=items[Math.floor(items.length/2)]; return {date,min:Math.round(Math.min(...temps)),max:Math.round(Math.max(...temps)),icon:mid.weather[0].icon,description:mid.weather[0].description,items:items.filter((x:any)=>new Date(x.dt*1000).getHours()%6===0).map((x:any)=>({time:new Date(x.dt*1000).toLocaleTimeString('en-US',{hour:'numeric'}),temp:Math.round(x.main.temp),icon:x.weather[0].icon}))};}); }
export function iconUrl(icon:string){return `https://openweathermap.org/img/wn/${icon}@2x.png`;}
