import AsyncStorage from '@react-native-async-storage/async-storage';
import {create} from 'zustand';
import {Weather} from '../services/weather';

type State={weather:Weather|null; favorites:string[]; dark:boolean; cachedAt:number|null; setWeather:(w:Weather)=>void; toggleFavorite:(city:string)=>void; setDark:(v:boolean)=>void; hydrate:()=>Promise<void>};
const KEY='skywatch-state-v1';
export const useWeatherStore=create<State>((set,get)=>({weather:null,favorites:[],dark:true,cachedAt:null,
 setWeather:(weather)=>{set({weather,cachedAt:Date.now()}); AsyncStorage.setItem(KEY,JSON.stringify({...get(),weather,cachedAt:Date.now()})).catch(()=>{});},
 toggleFavorite:(city)=>{const favorites=get().favorites.includes(city)?get().favorites.filter(x=>x!==city):[...get().favorites,city];set({favorites});AsyncStorage.setItem(KEY,JSON.stringify({...get(),favorites})).catch(()=>{});},
 setDark:(dark)=>{set({dark});AsyncStorage.setItem(KEY,JSON.stringify({...get(),dark})).catch(()=>{});},
 hydrate:async()=>{try{const raw=await AsyncStorage.getItem(KEY);if(raw){const v=JSON.parse(raw);set({weather:v.weather||null,favorites:v.favorites||[],dark:v.dark??true,cachedAt:v.cachedAt||null});}}catch{}}}));
